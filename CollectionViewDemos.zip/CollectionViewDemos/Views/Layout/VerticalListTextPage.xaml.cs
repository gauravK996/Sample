﻿using CollectionViewDemos.ViewModels;

namespace CollectionViewDemos.Views
{
    public partial class VerticalListTextPage : ContentPage
    {
        public VerticalListTextPage()
        {
            InitializeComponent();
        }
    }
}
