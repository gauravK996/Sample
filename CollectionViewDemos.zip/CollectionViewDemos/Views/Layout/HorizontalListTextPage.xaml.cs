﻿namespace CollectionViewDemos.Views
{
    public partial class HorizontalListTextPage : ContentPage
    {
        public HorizontalListTextPage()
        {
            InitializeComponent();
        }
    }
}
