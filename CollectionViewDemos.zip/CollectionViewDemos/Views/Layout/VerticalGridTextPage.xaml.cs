﻿namespace CollectionViewDemos.Views
{
    public partial class VerticalGridTextPage : ContentPage
    {
        public VerticalGridTextPage()
        {
            InitializeComponent();
        }
    }
}
