﻿namespace CollectionViewDemos.Views
{
    public partial class HorizontalGridTextPage : ContentPage
    {
        public HorizontalGridTextPage()
        {
            InitializeComponent();
        }
    }
}
